
rm(list=ls())
###########

library(graphics)  ### grafico de interacción
library(gplots) ## gráfico de medias 



############Leer datos
datos<-read.csv("crecimiento_bacterias.csv",sep=";", dec=",")
bateria<-read.csv("bateria.csv",sep=";")

datos$tiempo=as.factor(datos$tiempo)
datos$medio=as.factor(datos$medio)

bateria$temperatura=as.factor(bateria$temperatura)
bateria$material=as.factor(bateria$material)

attach(datos)
attach(bateria)


#########

boxplot(crecimiento~tiempo)
boxplot(crecimiento~medio)

#######3

plotmeans(crecimiento~tiempo,bars=T)
plotmeans(crecimiento~medio,bars=T)



formula <- crecimiento  ~ tiempo + medio
plot.design(formula, col= "coral", xlab="Efectos", ylab="Promedio de crecimiento")



interaction.plot(tiempo, medio,crecimiento, ylab="Promedio de crecimiento")

###############################3



anova_bat=aov(tiempo_horas~material+temperatura+temperatura*material)

summary(anova_bat)

### tabla de efectos
efectos<-model.tables(x=anova_bat,type="effects")


### tabla de medias
medias<-model.tables(x=anova_bat,type="means")






