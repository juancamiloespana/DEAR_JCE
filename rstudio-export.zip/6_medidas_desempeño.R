
library(Metrics) ##Para calcular MAPE, RMSE MAE
library(car) ### para gráfico qqplot
library(randomForest) ### para ver importancia de variables

################## Crear una base de datos ################
################## y es el precio de una vivienda en millones de pesos #########
################## x son los metros cuadrados
################ X2 número de rutas de transporte público #####
###### X3 número de habitaciones


set.seed(100)
x=runif(n=1000,min=20,max=80) #### Genera variable aleatoria 'x' con distribución uniforme de 20 a 80
x2=runif(n=1000,min=5,max=20)
x3= rnorm(n=1000,50,1)
  


e=rnorm(1000,0,2) ### Se genera un error aleatorio normal

y= 30 + 0.5*x + 0.3*x2+ e  #### Genera la variable respuesta con base en ecuación de recta

y[901:1000]= runif(10,150,200) #### Genera atípicos para la variable respuesta

base_modelo=data.frame(y,x,x2,x3)




########## 1. Crear modelo de regresión con metros cuadrados
######### 1.1 explicar la salida.

modelo1<-lm(base_modelo$y~base_modelo$x)
summary(modelo1)

mean(base_modelo$y)


##### 2. completar estas funciones
AIC(modelo1)
BIC(modelo1)



predichos<-predict(modelo1)
predichos<-modelo1$fitted.values

mae(base_modelo$y,predichos)
mape(base_modelo$y,predichos)

mse(base_modelo$y,predichos)
rmse(base_modelo$y,predichos)




##### 3. ELiminar atípicos y comparar modelos


lim_sup<- quantile(y,0.75) +(IQR(y)*1.5 ) 
lim_inf<- quantile(y,0.25) - (IQR(y)*1.5 ) 

base_modelo2=subset(base_modelo, y<=lim_sup & y>lim_inf)



modelo2<-lm(base_modelo2$y~base_modelo2$x)
predichos2<-predict(modelo2)

mae(base_modelo2$y,predichos2)
mae(base_modelo$y,predichos)


mape(base_modelo2$y,predichos2)
mape(base_modelo$y,predichos)

mse(base_modelo2$y,predichos2)
mse(base_modelo$y,predichos)

rmse(base_modelo2$y,predichos2)
rmse(base_modelo$y,predichos)

summary(modelo2)
summary(modelo1)

AIC(modelo2)
AIC(modelo1)

BIC(modelo2)
BIC(modelo1)







##### 4. agregar segunda variable y comparar modelos


modelo3<-lm(base_modelo2$y~base_modelo2$x +base_modelo2$x2)
predichos3<-predict(modelo3)

mae(base_modelo2$y,predichos3)
mae(base_modelo2$y,predichos2)
mae(base_modelo$y,predichos)

mape(base_modelo2$y,predichos3)
mape(base_modelo2$y,predichos2)
mape(base_modelo$y,predichos)

mse(base_modelo2$y,predichos3)
mse(base_modelo2$y,predichos2)
mse(base_modelo$y,predichos)

rmse(base_modelo2$y,predichos3)
rmse(base_modelo2$y,predichos2)
rmse(base_modelo$y,predichos)

summary(modelo3)
summary(modelo2)
summary(modelo1)

AIC(modelo3)
AIC(modelo2)
AIC(modelo1)

BIC(modelo3)
BIC(modelo2)
BIC(modelo1)









