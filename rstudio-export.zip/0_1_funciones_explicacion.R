




### para ayudas de funciones
help(runif)
help(rnorm)
help(lm)
help(plot)

###crear datos ficticios 

anos_exp<-rnorm(n=1000,  mean=20, sd=2) ### Función para crear npumeros aleatorios normales
anos_exp2<-runif(n=1000, max=20, min=0) ### Función para crear npumeros aleatorios uniformes
hist(anos_exp) ###para gráficas hsitograma

salario<-300*anos_exp2 + rnorm(n=1000, mean=0, sd=700) ###para crear variable respuesta que depena de explicativa y con error aleatorio normal

datos<-data.frame(anos_exp2,salario) ###Con base en variables aleatorioas crar una tabla tipo data.frame


plot(datos$anos_exp2,datos$salario) ###para gráfico de dispersión x y y


modelo1<-lm(salario~anos_exp2)
###para ajustar modelo de regresión lineal desde variables y no desde tabla
modelo2<-lm( formula=salario~anos_exp2, data=datos)  ###para ajustar modelo de regresión lineal desde data frame

summary(modelo2) ### para ver resumen de modelo de regresión lineal

hist(x=modelo2$residuals) ### histograma de residuales

modelo2$fitted.values ### para ver valores predichos














