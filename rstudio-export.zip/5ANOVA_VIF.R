#####CArgar paquetes #############3

library(regclass)

####### 
##################Crear una base de datos ficticia

edad<-seq(20,50)
antibiotico<-case_when(
  runif(31,0,1) >=0.5 ~"SI",
  TRUE ~"NO"
)


y<-case_when(
  antibiotico=="SI"~ edad*0.7,
  TRUE ~ 50-edad*0.5
)


############################

boxplot(edad~antibiotico)

datos<-data.frame(y,edad,antibiotico)

plot_ly(data=datos,y=~y,x=~edad, color=~antibiotico, type="scatter")




reg<-lm(y~edad+antibiotico)
summary(reg)
anova<-aov(reg)
summary(anova)


pruebaf<-linearHypothesis(reg, c("edad=0", "antibioticoSI=0"))




#####VIF  

VIF(reg)
vifs<-data.frame(VIF(reg))


#########

####Suponga y utilidad de empresa
#### suponga x gasto en publicidad
#### Suponga x2 gasto en calidad


x=runif(1000,15,70)
y=3*x +rnorm(1000,0,1)

x2=x+rnorm(1000,0,10)

cor(x,x2)

modelo<-lm(y~x+x2)
VIF(modelo)

summary(modelo)


