##### 0 Cargar librer?aas, ya deben estar instaladas ######

library(car)
library(tseries)
library(nortest)
library(goftest)
library(lmtest)

##### 1. cargar datos ####

datos<-read.csv("precio_viviendas.csv")



###### Descripción de los datos.
summary(datos)

plot(datos$m2, datos$precio)

hist(datos$m2)
densityPlot(datos$m2)
boxplot(datos$precio)

mod1<- lm(datos$precio~datos$m2)
summary(mod1)

######


lim_sup<-quantile(datos$precio,0.75) + (IQR(datos$precio))

datos_dep<-subset(datos, datos$precio <=lim_sup)


summary(datos_dep)

densityPlot(datos_dep$m2)
par(mfrow=c(1,2))

plot(datos_dep$m2,datos_dep$precio)
plot(datos$m2, datos$precio)

mod2<-lm(data=datos_dep, precio~m2)

mean(datos_dep$precio)


abline(mod2)
summary(mod2)

summary(datos_dep)


residuales<-mod2$residuals


#1. prueba normalidad ####

##1.1 Normalidad - Pruebas gráficas #####

#Histograma

hist(residuales, main="Histograma residuales", breaks=20)

#qqplot sencillo

qqnorm(residuales)
qqline(residuales)

#qqplot fancy
qqPlot(residuales)


boxplot(residuales, horizontal=T)

##1.2 Normalidad -pruebas estadísticas #########


shapiro.test(residuales) ##shapiro wilk

jarque.bera.test(residuales) ###jarque bera test

ks.test(x=residuales,pnorm,0,sd(residuales)) ####kolmogorov smirnov

ad.test(residuales, pnorm, 0, sd(residuales))  ###Anderson darling

cvm.test(residuales,pnorm, 0, sd(residuales)) ###Cramer von mises

#2. prueba varianza constante - Homocedasticidad ####

##2.1 Homocedasticidad -Pruebas gráficas #####


plot(mod2$fitted.values,residuales)
abline(h=0, col="red")

plot(datos_dep$precio,residuales)
abline(h=0)

##2.2 Homocedasticidad -Pruebas estadísticas #####

bptest(mod2)



#3. prueba independencia  #####


##3.1 Independencia-Pruebas GRáficas #####

plot(residuales)
abline(h=0)
par(mfrow=c(1,2)) ###Separar la ventana de los gráficos
acf(residuales)
pacf(residuales)

##3.2 Independencia-Pruebas estadísticas #####

dwtest(mod2) 

bgtest(mod2)
########### corrección de incumplimiento


trans<-powerTransform(mod2)
summary(trans)


###############


ymod<-log(datos_dep$precio)
xmod=x^2

mod3<-lm(ymod~xmod)

plot(datos_dep$m2, ymod)

confint(mod2)

