
######## 1. Leer datos ######
###Cargar los datos desde un archivo .csv
##El separador de columnas 'sep' y separador decimal 'dec' pueden variar con la configuracion del pc
###si los datos no estÃ¡n dentro del proyecto, se debe poner la ruta completa donde estÃ¡:
### "D:/catedra/Salary_Data.csv"
###Si se pone mal el separador decimal, puede leer un valor nÃºmerico como texto
### Si se pone mal el separador de columnas, reconoce todo como si fuera una columna


datos_resistencia<-read.csv("resistencia.csv",dec=".",sep=";", header= T, fileEncoding = "UTF-8")


#####Diagrama de dispersión

plot(datos_resistencia$porcentaje,datos_resistencia$resistencia)


####Ajustar modelo de regresión lineal
modelo<-lm(formula=resistencia~porcentaje, data=datos_resistencia)


####GRafico de dispersión con modelo ajustado
plot(datos_resistencia$porcentaje,datos_resistencia$resistencia)
abline(modelo, col="red")


###REsumen del modelo

summary(modelo)

###Calcular MSE manualmente

sqrt(sum(modelo$residuals^2)/(length(datos_resistencia$porcentaje)-2))

mean(datos_resistencia$resistencia)

####Intervalos de confinza para B1 y B0

confint(modelo,level=0.90)


###### intervalos de Predicciones

predict(modelo) ###Valores predichos de la base utilizada, se puede usar para predecir conjunto de datos nuevo(lo veremos en regresión lineal múltiple)
modelo$fitted.values ## valores ajustados iguales a los de función predict (no aplica para datos nuevos)

data.frame(predict(modelo),modelo$fitted.values)

confidencia<-predict(modelo, interval="confidence") ###Intervalo de confianza para valores predichos de datos con los que se ajustó el modelo
prediccion<-predict(modelo, interval="prediction")  ### Intervalo de confianza para valores predichos de datos nuevos a los que se utilizaron para ajustar el modelo

data.frame(confidencia, prediccion)




